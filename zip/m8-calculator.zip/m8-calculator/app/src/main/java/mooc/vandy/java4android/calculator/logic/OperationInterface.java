package mooc.vandy.java4android.calculator.logic;

/**
 * Defines the Interface for all operations
 */
public interface OperationInterface {
    /**
     * performs an operation
     */
    String toString();
}
